package org.example;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)   {
        Scanner scanner=new Scanner(System.in);
        String filePath = "accounts.txt"; // Default file path
        ArrayList<UserAccount> accounts = Operations.readFileAndSaveToList(filePath);
        Operations.readListAndWriteToFile(accounts, filePath);
        System.out.println("Welcome ");

        int incorrectEntry =0;
        boolean flag=true;
        ArrayList<UserAccount> userAccounts = Operations.readFileAndSaveToList(filePath);

        while (flag){
            System.out.println("1- Bank Entry");
            System.out.println("2- Bank Tps");
            System.out.println("3- exit");

            System.out.println("Please choose  your option ");
            byte option=scanner.nextByte();
            switch (option) {
                case 1:
                    Operations.BankEntry(filePath,userAccounts);
                    break;
                case 2:
                    Operations.BankTps(userAccounts, filePath);
                    break;
                case 3:
                    flag=false;
                    break;
                default:
                    incorrectEntry++;
                    if (incorrectEntry ==3) {
                        System.out.println("you input 3 times incorrect option ");
                        flag=false;
                    }
            }


        }
     }
}