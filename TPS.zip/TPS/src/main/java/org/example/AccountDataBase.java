package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccountDataBase {
    public List<UserAccount> createDB(String filePath) {
        List<UserAccount> accountList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Assuming each line in the file corresponds to an Account
                String[] parts = line.split(", ");

                // Extracting data and creating an Account object
                String accountNumber = parts[0].split("=")[1];
                String holder = parts[1].split("=")[1];
                double balance = Double.parseDouble(parts[2].split("=")[1]);

                UserAccount account = new UserAccount(accountNumber, holder, balance);
                accountList.add(account);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return accountList;
    }
}