package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static int failedTransaction = 0;
    public static void main(String[] args)   {
        Scanner scanner=new Scanner(System.in);
        String filePath = "accounts.txt"; // Default file path
        ArrayList<UserAccount> accounts = readFileAndSaveToList(filePath);
        readListAndWriteToFile(accounts, filePath);

        System.out.println("Welcome ");
        byte uinput1=0;
        String username="";
        String useraccount="";
         double userbalance=0;


        ArrayList<UserAccount>userAccounts=readFileAndSaveToList(filePath);




        StringBuilder journalammount=new StringBuilder();








int incorrecttry=0;
        boolean flag=true;

        System.out.println("1- Bank Entry");
        System.out.println("2- Bank Tps");


        while (flag){
            System.out.println("Please choose  your option ");

            String option=scanner.next();

            if (option.equals("1")) {
                System.out.println("you choose Bank Entry");
                BankEntry(username,useraccount,userbalance,userAccounts);

             }
            else if (option.equals("2")){
                System.out.println("you chooseBank Tps ");
                BankTps(userAccounts, filePath);




            } else if (option.equalsIgnoreCase("exit")) {
                flag=false;


            } else {

                incorrecttry++;
                if (incorrecttry==3) {
                    System.out.println("you input 3 times incorrect option ");
                    flag=false;
                }
            }






        }





     }


    private static void BankEntry( String username,String useraccount,double userbalance ,ArrayList<UserAccount> userAccounts)  {
        UserAccount account1=new UserAccount();


        Scanner sc=new Scanner(System.in);
        System.out.println("enter account name!");
        username=  sc.nextLine();

        try {

            account1.setAccountHolder(username);
            account1.isValidName();

        }catch (UserAccountException e){
            System.out.println(e.getMessage());
            System.exit(1);

        }


        System.out.println("enter account number!");
        useraccount= sc.next();



        try (
                FileReader fr=new FileReader("accounts.txt");
                BufferedReader br=new BufferedReader(fr);

        ){
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line+"\n");
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        for (int i = 0; i < userAccounts.size(); i++) {
            if (userAccounts.get(i).getAccountNumber().equals(useraccount)){
                System.out.println("this user account name already exists");
                System.exit(1);

            }
        }

        sc.nextLine();
        try {
            account1.setAccountNumber(useraccount);
            account1.isValidAccountNumber();
        }catch (UserAccountException e){
            System.out.println(e.getMessage());
            System.exit(1);

        }

        System.out.println("enter Intital blance for account !");
        userbalance= sc.nextDouble();
        try {
            account1.setAccountBalance(userbalance);
            account1.isValidBalance();

        }catch (UserAccountException e){
            System.out.println(e.getMessage());
            System.exit(1);

        }
        UserAccount  account=new UserAccount(username,useraccount,userbalance);

        try (FileWriter fileWriter = new FileWriter("accounts.txt",true);
             BufferedWriter br = new BufferedWriter(fileWriter);) {
            br.write(String.valueOf(account));
            System.out.println("you added into accounts file successfilly");
            br.newLine();
            userAccounts.add(account);

        }
        catch (Exception e ) {
            System.out.println(e.getMessage());
        }









    }
    private static void BankTps(     ArrayList<UserAccount> userAccounts, String path) {

        Scanner sc=new Scanner(System.in);

        boolean c=true;
       while (c){
           System.out.println("---------------------");
           System.out.println("choose operation no!");
                                                ////entry done
           System.out.println("1-journal ");  /////done
           System.out.println("2-balance sheet "); //done
           System.out.println("3-transactions count ");
           System.out.println("4-accounts names with highest balances ");  //done
           System.out.println("5-failed transactions count ");
           System.out.println("6- exit ");//done
           System.out.println("7- Close the program ");
          byte uinput= sc.nextByte();

           switch (uinput) {
               case 1:
                   journal(userAccounts, path);
                   break;
               case 2:
                   banksheet();
                   break;

               case 3:
                   System.out.println("choose 3");
                   break;
               case 4:

                   accountsHighestDalances(userAccounts,"accounts.txt");
                    break;

               case 5:
                   failed();
                   break;
               case 6:
                   c=false;
                   System.out.println("1- Bank Entry");
                   System.out.println("2- Bank Tps");
                    break;
               case 7:
                   System.exit(1);
               default:
                   System.exit(1);




           }

       }


    }

    private static void banksheet() {
        try (
                FileReader fr=new FileReader("accounts.txt");
                BufferedReader br=new BufferedReader(fr);
        ){
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line+"\n");
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public static void readListAndWriteToFile(ArrayList<UserAccount> accounts, String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (UserAccount account : accounts) {
                bw.write(account.toString());
                bw.newLine();
            }
            System.out.println("Accounts written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<UserAccount> readFileAndSaveToList(String filePath) {
        ArrayList<UserAccount> userAccounts = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                String accountNumber = parts[0].split("=")[1];
                String holder = parts[1].split("=")[1];
                double balance = Double.parseDouble(parts[2].split("=")[1]);
                UserAccount account = new UserAccount(accountNumber, holder, balance);
                userAccounts.add(account);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userAccounts;
    }




    private static void accountsHighestDalances(ArrayList<UserAccount> userAccounts, String filePath){

        // Replace with the actual path to your text file

        List<UserAccount> accountList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {

                String[] parts = line.split(", ");

                String accountNumber = parts[0].split("=")[1];
                String holder = parts[1].split("=")[1];
                double balance = Double.parseDouble(parts[2].split("=")[1]);

                UserAccount account = new UserAccount(accountNumber, holder, balance);
                accountList.add(account);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<UserAccount> sorthigh = accountList.stream()
                .sorted(Comparator.comparing(UserAccount::getAccountBalance).reversed())
                .limit(6).collect(Collectors.toList());
        System.out.println("Top 6 accounts with the highest balance:");
        sorthigh.forEach(account ->
                System.out.println("Account Holder: " + account.getAccountHolder() +
                        ", Balance: " + account.getAccountBalance()));


    }


    public static void journal(ArrayList<UserAccount> users, String path ){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter operation: ");
        String transactionType = sc.next();
        if (transactionType.equalsIgnoreCase("exit"))
            BankTps(users, path);
        if (!transactionType.equalsIgnoreCase("credit") && !transactionType.equalsIgnoreCase("debit")){
            System.out.println("Invalid Operation");
            journal(users, path);
        }
        System.out.println("Enter amount: ");
        double amount = sc.nextDouble();
        if (amount<0)
            try {
                throw new UserAccountException(UserErrorCode.NegativeBalance);
            } catch (UserAccountException e) {
                failedTransaction++;
                System.out.println(e.getMessage());
                journal(users, path);
            }

        System.out.println("Enter account number: ");
        String userAccountNumber = sc.next();
        UserAccount user = new UserAccount();
        user = user.findUserByAccountNumber(userAccountNumber, users);
        System.out.println("Holder: " + user.getAccountHolder());
        int index = users.indexOf(user);

        if (user == null){
            System.out.println("Account Number not found");
            journal(users, path);
        }

        if (transactionType.equalsIgnoreCase("credit")){
            user.deposit(amount);
            users.set(index, user);
            readListAndWriteToFile(users, path);
        } else if (transactionType.equalsIgnoreCase("debit")) {
            try {
                user.withdraw(amount);
                users.set(index, user);
                readListAndWriteToFile(users, path);
            } catch (UserAccountException e) {
                failedTransaction++;
                System.out.println(e.getMessage());
                journal(users, path);
            }
        }
    }

    public static void failed(){
        System.out.println("Number of failed Transactions: "+failedTransaction);
    }


}