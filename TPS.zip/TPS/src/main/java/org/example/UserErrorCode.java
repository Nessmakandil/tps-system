package org.example;

public enum UserErrorCode {
    UserNameContainsNumbers, UserNameTooShort, UserAccountNumberTooShort, InvalidUserAccountNumber, NegativeBalance,AmountNotAllowed, NegativeCredit
}
